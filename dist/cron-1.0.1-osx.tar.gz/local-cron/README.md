# Slack Wifi Status

Set your Slack status to either :house_with_garden: or :coffee: (or some custom emoji) based on your location, which you can add via a custom Slackbot 'Earl'.

You list a set of locations, if you're at that place, then your status is set to

> :pick an emoji: My custom status

If you are at a location not on the list, then your status is set the `else`-default

> :coffee: At a coffee shop


## Setup

Clone the repo:

```
git clone git@bitbucket.org:mantebridts/slackupdatestatus.git
```
Install the required gems:

```
cd slackupdatestatusxcode-select --install
/usr/bin/ruby -e "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install)"
bundle install
brew cask install corelocationcli
CoreLocationCLI -json
```

You can test your setup by running

```
./bin/update-slack-status "your-secret-token-here"
```

It should update your status on Slack.

## Automatically updating your status

Setup a cron job that runs every five minutes and runs `bin/update-slack-status`, use this command to use nano to edit the crontab-file:

```export VISUAL=nano; crontab -e```

and put this line in the file

```
*/5 * * * * cd /Users/yourname/path/to/code/slack-update-status && ./bin/update-slack-status "your-secret-token-here"> /dev/null 2> /dev/null
```
